import React, { useMemo } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useTable, useSortBy } from 'react-table';
import { FaTrash, FaEdit, FaSort, FaSortUp, FaSortDown } from 'react-icons/fa';
import { editData, deleteData, sortData } from "../redux/actions";
import { Details } from "./form";

type TableProps = {
  editRow: (rowData: any) => void;
};

type RootState = {
  data: Details[];
};

type Column = {
  Header: string;
  accessor: keyof Details;
  disableSortBy?: boolean;
  Cell?: (props: any) => JSX.Element;
  isSorted?: boolean;
  isSortedDesc?: boolean;
};

function Table({ editRow }: TableProps) {
  const data = useSelector((state: RootState) => state.data);
  const dispatch = useDispatch();

  const columns: Column[] = useMemo(
    () => ([
      { Header: 'Employee Name', accessor: 'Employee Name' as keyof Details },
      { Header: 'Gender', accessor: 'Gender' as keyof Details },
      { Header: 'Department', accessor: 'Department' as keyof Details },
      { Header: 'Date of Join', accessor: 'Date of Join' as keyof Details },
      { Header: 'Email', accessor: 'Email' as keyof Details },
      {
        Header: 'Action',
        accessor: 'Action' as keyof Details,
        disableSortBy: true,
        Cell: ({ row }) => (
          <div className="action">
            <FaTrash onClick={() => handleDelete(row.index)} className="fa-trash" />
            <FaEdit onClick={() => editRow(row.original)} className="fa-edit" />
          </div>
        )
      }
    ]),
    [editRow]
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
    },
    useSortBy
  );

  const handleSort = (column: Column) => {
    if (!column.disableSortBy) {
      const direction = column.isSortedDesc ? 'asc' : 'desc';
      dispatch(sortData(column.accessor, direction));
    }
  };

  const handleDelete = (rowIndex: number) => {
    if (rowIndex >= 0 && rowIndex < data.length) {
      dispatch(deleteData(rowIndex));
    } else {
      console.error("Invalid row index:", rowIndex);
    }
  }

  return (
    <table
      id='table'
      className='table-container'
      style={{ display: data.length === 0 ? 'none' : 'table' }}
      {...getTableProps()}>
      <thead>
        {headerGroups.map((headerGroup: any) => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map((column: any) => (
              <th
                {...column.getHeaderProps(column.disableSortBy ? {} : column.getSortByToggleProps())}
                onClick={() => handleSort(column)} >
                {column.render('Header')}
                {!column.disableSortBy && (
                  <span>
                    {column.isSorted ? (column.isSortedDesc ?  '▼ ' : '▲') : <FaSort />}
                  </span>
                )}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows && rows.map((row: any, rowIndex: number) => {
          prepareRow(row);
          return (
            <tr key={rowIndex} {...row.getRowProps()}>
              {row.cells.map((cell: any, cellIndex: number) => (
                <td key={cellIndex} {...cell.getCellProps()}>
                  {cell.render('Cell')}
                </td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

export default Table;
