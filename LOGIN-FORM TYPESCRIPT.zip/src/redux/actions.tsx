// actions.ts
import * as actionTypes from './actiontypes'; 

export type Details = {
  'Employee Name': string;
  'Gender': string;
  'Department': string;
  'Date of Join': string;
  'Email': string;
};

export const addData = (data: Details) => ({ 
  type: actionTypes.ADD_DATA,
  payload: data
});

export const validateData = (errors: any) => ({ 
  type: actionTypes.VALIDATE_DATA,
  payload: errors
});

export const sortData = (column: string, direction: string) => ({ 
  type: actionTypes.SORT_DATA,
  payload: { column, direction }
});

export const editData = (index: number, details: Details) => ({
  type: actionTypes.EDIT_DATA,
  payload: { index, details } 
});

export const deleteData = (index: number) => ({
  type: actionTypes.DELETE_DATA,
  payload: index
});
