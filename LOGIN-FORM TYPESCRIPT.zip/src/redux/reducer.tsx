// reducer.ts
import { ADD_DATA, VALIDATE_DATA, SORT_DATA, EDIT_DATA, DELETE_DATA } from './actiontypes';

// Define initial state type
type State = {
  data: any[];
  formErrors: any;
};

// Define action types
type Action =
  | { type: typeof ADD_DATA; payload: any }
  | { type: typeof VALIDATE_DATA; payload: any }
  | { type: typeof SORT_DATA; payload: { column: string; direction: 'asc' | 'desc' } }
  | { type: typeof EDIT_DATA; payload: { index: number; details: any } }
  | { type: typeof DELETE_DATA; payload: number };

// Define initial state
const initialState: State = {
  data: [],
  formErrors: {},
};

// Define rootReducer function
const rootReducer = (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case ADD_DATA:
      return {
        ...state,
        data: [...state.data, action.payload],
      };
      case VALIDATE_DATA:
        return {
          ...state,
          formErrors: action.payload, // Corrected from data to formErrors
        };
      
    case SORT_DATA:
      const { column, direction } = action.payload;
      const sortedData = [...state.data].sort((a, b) => {
        if (direction === 'asc') {
          return a[column] > b[column] ? 1 : -1;
        } else {
          return a[column] < b[column] ? 1 : -1;
        }
      });
      return {
        ...state,
        data: sortedData,
      };
    case EDIT_DATA:
      const { index, details } = action.payload;
      const updatedData = [...state.data];
      updatedData[index] = details;
      return {
        ...state,
        data: updatedData,
      };
    case DELETE_DATA:
      const dataIndex = action.payload;
      const newData = [...state.data];
      newData.splice(dataIndex, 1);
      return {
        ...state,
        data: newData,
      };
    default:
      return state;
  }
};

export default rootReducer;
