export const ADD_DATA = 'ADD_DATA';
export const VALIDATE_DATA = 'VALIDATE_DATA';
export const SORT_DATA = 'SORT_DATA';
export const EDIT_DATA = 'EDIT_DATA';
export const DELETE_DATA = 'DELETE_DATA';
